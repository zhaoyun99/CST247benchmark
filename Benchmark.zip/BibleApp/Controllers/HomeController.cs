﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using BibleApp.Models;
using BibleApp.Service.Utility;

namespace BibleApp.Controllers
{
    public class HomeController : Controller
    {
      

        [Unity.Dependency]
        public ILogger logger = new MyLogger2();

      

        public ActionResult Index()
        {
            return View();
        }

    }
}
