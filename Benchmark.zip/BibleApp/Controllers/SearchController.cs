﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using BibleApp.Models;
using BibleApp.Service.Business;
using BibleApp.Service.Utility;
using Microsoft.AspNetCore.Mvc;

namespace BibleApp.Controllers
{
    public class SearchController : Controller
    {
        [Unity.Dependency]
        public ILogger logger = new MyLogger2();

        // GET: Search
        public ActionResult Index()
        {
            return View();
        }

        // POST: Verse searching
        [HttpPost]
        public ActionResult Search(VerseModel model)
        {
            if (!ModelState.IsValid)
            {
                return View("Index");
            }

            VerseService service = new VerseService(model);
            List<string> text = service.SearchVerses();
            return View("Results", text);
        }
    }
}
